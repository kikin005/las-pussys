<?php
include 'conexion.php';

// Establecer el tipo de contenido como JSON
header("Content-Type: application/json");

function obtenerregistros($conn) {
    $sql = "SELECT matricula, nombre, direccion FROM tbalumnos"; // Seleccionar solo las columnas necesarias
    $result = $conn->query($sql);
    $alumnos = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $alumnos[] = $row;
        }
    }

    return $alumnos;
}

$registros = obtenerregistros($conn);
$conn->close();

// Enviar los datos en formato JSON
echo json_encode($registros);
?>
