<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

// Incluir el archivo de conexión
include 'conexion.php';
// Obtener el cuerpo de la solicitud
$data = json_decode(file_get_contents("php://input"), true);
// Procesar formulario
if ($_SERVER["REQUEST_METHOD"] === "POST") {

    // Verificar si los datos están completos
if (!isset($data['matricula']) || !isset($data['nombre']) || !isset($data['direccion'])) {
    echo json_encode(array("error" => "Datos incompletos"));
    exit();
}
        try {
            $stmt = $conn->prepare("INSERT INTO tbalumnos (matricula,nombre,direccion) VALUES(?, ?, ?)");
            
            $stmt->bind_param("sss", 
                 $data['matricula'],
                $data['nombre'],
                $data['direccion']
                
            );
            
            if ($stmt->execute()) {
                if ($stmt->affected_rows > 0) {
                    echo json_encode(array("mensaje" => "Alumno registrado correctamente"));
                } else {
                    echo json_encode(array("error" => "No se registró el alumno"));
                }
            } else {
                echo json_encode(array("error" => "Error al grabar"));
            }
            
            $stmt->close();
        } catch(Exception $e) {
            echo json_encode(array("error" => "Error: " . $e->getMessage()));
        }
} else {
    echo json_encode(array("error" => "Método no permitido"));
}

$conn->close();


/*// Dentro del bloque POST


    $stmt = $conn->prepare("INSERT INTO registros (matricula, nombre, direccion) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $matricula, $nombre, $direccion);

$matricula = $_POST['matricula'];
$nombre = $_POST['nombre'];
$direccion = $_POST['direccion'];

if ($stmt->execute()) {
    // Registro exitoso
} else {
    // Manejo de error
}
// Limpiar y validar datos
    $matricula = $conn->real_escape_string($_POST['matricula']);
    $nombre = $conn->real_escape_string($_POST['nombre']);
    $direccion = $conn->real_escape_string($_POST['direccion']);
    
    // Insertar datos
    $sql = "INSERT INTO tblalumnos (matricula, nombre, direccion)
            VALUES ('$matricula', '$nombre', '$direccion')";
    
    if ($conn->query($sql) === TRUE) {
        echo "<h1>Registro exitoso!</h1>";
   
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
*/

?>