<?php
$servername = "localhost";
$username = "root";  // Tu usuario de MySQL
$password = "";      // Si tienes contraseña, agrégala
$dbname = "isoftdb";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Error en la conexión: " . $conn->connect_error);
}
?>
