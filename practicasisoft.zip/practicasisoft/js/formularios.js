function validarFormulario() {
    const id_alumno = document.getElementById('id_alumno').value;
    // Puedes agregar más validaciones aquí
    if (id_alumno.length < 3) {
        alert('La matrícula debe tener al menos 3 caracteres');
        return false;
    }
    return true;
}